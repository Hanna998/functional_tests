	#In other words, if you have some code that says:
wibble = 3
	#There’s not much point in a test that says:
from myprogram import wibble
assert wibble == 3

